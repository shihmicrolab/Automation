function [redValAvg ,greenValAvg ,blueValAvg] = rgb( handles,hObject,imageAnalyze,p_x,p_y,i,variation )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

rgbtableData = get(handles.rgbTable,'Data');

%% COLOR METHOD
% Initialize the colorSum
redValSum= 0 ;
greenValSum= 0;
blueValSum= 0;

p_x1 = p_x - variation;
p_y1 = p_y - variation;

p_x2 = p_x + variation;
p_y2 = p_y - variation;

p_x3  = p_x - variation;
p_y3  = p_y + variation;

p_x4  = p_x + variation;
p_y4  = p_y + variation;

position_x_min = p_x1;
position_x_max = p_x4;

position_y_min = p_y1;
position_y_max = p_y4;

viscircles(handles.image_axe,[p_x1 p_y1],1);
viscircles(handles.image_axe,[p_x2 p_y2],1);
viscircles(handles.image_axe,[p_x3 p_y3],1);
viscircles(handles.image_axe,[p_x4 p_y4],1);

position_x_min = round(position_x_min);
position_y_min = round(position_y_min);
position_x_max = round(position_x_max);
position_y_max = round(position_y_max);

% Taking the average
% Red values

% PROBLEM, I KEEP GETTING 255 as redValSum -> because
% imageAnalyze (x,y,1) returns -> unit8
% we have to convert it to double

% Dont know why but image(x,y,#) -> Error (the x and y are
% inverted here).

for x = position_x_min:1:position_x_max
    for y = position_y_min:1:position_y_max
        
        redValSum = imageAnalyze(y,x,1) + redValSum;
        
    end
end

% Green values
for x = position_x_min:1:position_x_max
    for y = position_y_min:1:position_y_max
        
        greenValSum = imageAnalyze(y,x,2) + greenValSum;
        
    end
end

% Blue values
for x = position_x_min:1:position_x_max
    for y = position_y_min:1:position_y_max
        
        blueValSum = imageAnalyze(y,x,3) + blueValSum;
        
    end
end

xDistance = (position_x_max - position_x_min) + 1;
yDistance = (position_y_max - position_y_min) + 1;
valAvg = xDistance * yDistance;

redValAvg = redValSum / valAvg;
greenValAvg = greenValSum / valAvg;
blueValAvg = blueValSum / valAvg;

rgbtableData{i,1} = redValAvg*255;
rgbtableData{i,2} = greenValAvg*255;
rgbtableData{i,3} = blueValAvg*255;

set(handles.rgbTable,'Data',rgbtableData);

end

