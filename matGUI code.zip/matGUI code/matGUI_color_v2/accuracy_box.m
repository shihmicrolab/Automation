function [ ] = accuracy_box( handles,hObject,accuracyValue)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

lineObj = findobj(handles.image_axe,'Type','line');

delete(lineObj);

coordinatetableData = get(handles.coordinateTable,'Data');

variation = (str2double(get(handles.electrodeDimensionEText,'String'))/2)/accuracyValue;

value0 = get(handles.zeroMinButton,'Value');
value40 = get(handles.fortyMinButton,'Value');
value80 = get(handles.eightyMinButton,'Value');
value120 = get(handles.hundredtwentyMinButton,'Value');

checkValueArray = zeros (1,4);

checkValueArray(1,1) = value0;
checkValueArray(1,2) = value40;
checkValueArray(1,3) = value80;
checkValueArray(1,4) = value120;

hold(handles.plot_axe,'on');

for i = 1:1:4
    
    if checkValueArray(1,i) == 1
        
        p_x = coordinatetableData(i,1);
        p_y = coordinatetableData(i,2);
        
        imageName = get(handles.loadedImageNameSText,'String');
        image = imread(imageName);
        image = im2double(image);
        
        [redValAvg ,greenValAvg ,blueValAvg] = rgb( handles,hObject,image,p_x,p_y,i,variation );
        
        switch i
            
            case 1
                rectangle(handles.color_axe1,'Facecolor',[redValAvg greenValAvg blueValAvg]);
            case 2
                rectangle(handles.color_axe2,'Facecolor',[redValAvg greenValAvg blueValAvg]);
            case 3
                rectangle(handles.color_axe3,'Facecolor',[redValAvg greenValAvg blueValAvg]);
            case 4
                rectangle(handles.color_axe4,'Facecolor',[redValAvg greenValAvg blueValAvg]);
                
        end
        
        scatter_pnts = scatter(handles.plot_axe,i,blueValAvg*255);
        
    end
    
    
end

hold(handles.plot_axe,'off');

lineObj = findobj(handles.plot_axe,'Type','line');
 
delete(lineObj);

end



