function [  ] = actuate_electrode( i,j, electrode_number,handles,hObject )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

% Converting the numbers from (user input) to which max we are talking. 

address  = conversion_2_arduino_address( handles , electrode_number );
actNum  = conversion_2_arduino_actNum(  electrode_number );




writeRegister(address,actNum,1);
disp(['Electrode = ',int2str(electrode_number), ' turned ON']);
disp_command(handles,['Electrode = ',int2str(electrode_number), ' turned ON']);

set(handles.Electrode_pad(i,j),'Backgroundcolor','green');

%Setting time electrode is on from the edit text box "time"
pause(handles.time_electrode);

writeRegister(address,actNum,0);
disp(['Electrode = ',int2str(electrode_number), ' turned OFF']);
disp_command(handles,['Electrode = ',int2str(electrode_number), ' turned OFF']);

set(handles.Electrode_pad(i,j),'Backgroundcolor','white');

end
