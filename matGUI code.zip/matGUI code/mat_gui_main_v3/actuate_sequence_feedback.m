function [  ] = actuate_sequence_feedback( handles,hObject,step_sequence )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

set(handles.phaseButton,'BackgroundColor','green','String','ACUTATION PHASE','Fontweight','bold');

% Init -> Calculating the entire time ON -> electrodes for the sequence to be processed

totaltimeON = 0;

% Re-init the reactuation table

% Getting information from the reactuation table

reactuationtableData = get(handles.reactuationTable,'Data');

% Make them empty

for i = 1:1:51
    for j = 1:1:14
        reactuationtableData {i,j} = '';
    end
end

% Saving information to the Reacuation table

set(handles.reactuationTable,'Data',reactuationtableData);

% Getting information from the reactuation table to get values

reactuationtableData = get(handles.reactuationTable,'Data');

if get(handles.feedbackTogglebutton,'Value') == 1
    
    %Getting info from master Table
    
    mastertableData = get(handles.masterTable,'Data');
    
    disp_command(handles,'Sequence Activated');
    
    handles = guidata(gcbo);
    
    counter = 0 ;
    
    j = 0;
    
    % Getting information from the sequence table
    
    sequencetableData = get(handles.sequenceTable,'Data');
    
    while counter ~= step_sequence %+ 1
        
        counter = counter + 1 ;
        
        j = j + 1;
        
        % Setting the increment string to "activated" collumn
        
        set(handles.sequencecollumnincrementText,'String',int2str(j));
        
        handles = guidata(gcbo);
        
        % Checking if user press the cancel button
        
        cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');
        
        if cancelsequence_flag == 1
            
            disp_command(handles,'Cancelling Operation...');
            
            cancelsequence_flag = 0;
            
            set(handles.cancelsequenceButton,'UserData',cancelsequence_flag);
            
            break
            
        end
        
        % Read the value of table and actuate the electrode
        
        for i = 1:1:6
            
            if isempty(sequencetableData{i,j}) == 1
                
                continue
                
            end
            
            electrode_number = sequencetableData{i,j};
            
            actuate_electrode_multiple_on_noij( electrode_number,handles,hObject );
            
            %Setting the Value in the master Table to " Actuated " -> so
            %that CHEKCING PHASE knows who to look at...
            
            mastertableData(electrode_number,5) = 1;
            
        end
        
        pause(handles.time_electrode);
        
        for i = 1:1:6
            
            if isempty(sequencetableData{i,j}) == 1
                
                continue
                
            end
            
            electrode_number = sequencetableData{i,j};
            
            actuate_electrode_multiple_off_noij( electrode_number,handles );
            
        end
        
        % Summing the time on
        
        timeON = handles.time_electrode;
        
        totaltimeON = totaltimeON +timeON;
        
        % Saving info to master table (WHICH ONE GOT ACTUATED (1st time))
        
        set(handles.masterTable,'Data',mastertableData);
        
        %%% CHECKING PHASE LOOP SHOULD BE HERE %%%
        
        % Reinit the numbers of Reactuations for one step (2, because in the table -> 1st is the 3 collumn)
        
        countNumReactuations = 2;
        
        % CHECKING PHASE LOOP
        reactuation_flag = 0;
        check_state = checking_phase( handles,counter );
        
        while check_state == false
            
            % Incrementing the time for electrode to STAY ON. (by 0.5 s each increment)
            
            % Putting a max time as safety measure
            
            if handles.time_electrode > 6
                
                disp ('The time electrode is on is more than 6s - Therefore we broke out')
                break
                
            end
            
            % Checking if user press the cancel button
            
            cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');
            
            if cancelsequence_flag == 1
                
                disp_command(handles,'Cancelling Operation...');
                
                break
                
            end
            
            handles.time_electrode = handles.time_electrode + 0.5 ;
            
            %Saving the time_electrode into handles
            
            guidata(hObject,handles);
            
            % Setting into the TIME BOX TEXT
            
            %set(handles.timeEdittext,'String',int2str(handles.time_electrode)) ;
            set(handles.timeEdittext,'String',num2str(handles.time_electrode)) ;
            
            
            % RE-ACTUATION PHASE
            re_actuation_phase( hObject,handles );
            
            % Summing the time on
            
            timeON = handles.time_electrode;
            
            totaltimeON = totaltimeON +timeON;
            
            
            
            %%% Saving Time info to reactuation table %%%
            
            stepNumber2reactuationtable = counter;
            
            %Indicator for numbers of reactuations for one step
            
            countNumReactuations = countNumReactuations + 1;
            
            % Putting the step that has reactuation
            
            reactuationtableData {stepNumber2reactuationtable,1} = stepNumber2reactuationtable;
            
            %Putting the Time that is ON
            
            reactuationtableData {stepNumber2reactuationtable,countNumReactuations} = timeON;
            
            %%% Saving Time info to reactuation table %%%
            
            % Flag that we are reactuating
            
            reactuation_flag = 1;
            
            % CHECKING PHASE
            check_state = checking_phase( handles,counter );
             
        end
        
        % Re-initialize the tables (EXTRA SAFETY) (OPTIONAL)
        
        mastertableData = get(handles.masterTable,'Data');
        
        tempsequencetableData = get(handles.tempsequenceTable,'Data');
        
        for i = 1:1:104
            
            mastertableData(i,4) = 0;
            mastertableData(i,5) = 0;
            
        end
        
        for i = 1:1:6
            
            tempsequencetableData{i,2} = '';
            
        end
        
        set(handles.masterTable,'Data',mastertableData);
        
        set(handles.tempsequenceTable,'Data',tempsequencetableData);
        
        % Puts the time back to 1 (Incremented by the CHECK PHASE LOOP)
        
        handles.time_electrode = str2double(get(handles.basetimeEdittext,'String'));
        
        guidata(hObject,handles);
        
        set(handles.timeEdittext,'String',num2str(handles.time_electrode));
        
        disp_command(handles,'FEEDBACK DONE');
        
        %%% CHECKING PHASE LOOP SHOULD BE HERE %%%
        
    end
    
end

%%% WHOLE Sequencing STOPS HERE

% Display that sequence is done

disp_command(handles,'Sequence Terminated');

% Setting the increment text back to 0

set(handles.sequencecollumnincrementText,'String','0');

% RE-INIT THE MASTERTABLE + TEMP SEQUENCE TABLE %

mastertableData = get(handles.masterTable,'Data');

tempsequencetableData = get(handles.tempsequenceTable,'Data');

for i = 1:1:104
    
    mastertableData(i,4) = 0 ;
    mastertableData(i,5) = 0 ;
    
end

for i = 1:1:6
    
    tempsequencetableData{i,2} = '';
    
end

set(handles.masterTable,'Data',mastertableData);

set(handles.tempsequenceTable,'Data',tempsequencetableData);

% RE-INIT THE MASTERTABLE + TEMP SEQUENCE TABLE %

%%%

%%% END %%%

% Sending information about the total time on

set(handles.totaltimeonStatictext,'String',num2str(totaltimeON));

% Set phase state

set(handles.phaseButton,'BackgroundColor','white','String','STAND-BY','Fontweight','bold');

if get(handles.absorbanceTogglebutton,'Value') == 1
    
    % Saving Absorbance Values into handles Structure
    
    handles.luxvaluesData =  luxvaluesData;
    
    guidata(hObject,handles);
    
end

% Saving information to the Reacuation table

set(handles.reactuationTable,'Data',reactuationtableData);

%ADDED SAFETY: TURNING ALL ELECTRODES OFF


%     for i = 1:1:104
%
%         electrode_number = i ;
%
%         address  = conversion_2_arduino_address( handles , electrode_number ) ;
%         actNum  = conversion_2_arduino_actNum(  electrode_number ) ;
%
%         writeRegister(address,actNum,0) ;
%
%         disp(['Electrode = ',int2str(electrode_number), ' turned OFF']);
%         disp_command(handles,['Electrode = ',int2str(electrode_number), ' turned OFF']);
%
%     end


%%% END %%%

end

