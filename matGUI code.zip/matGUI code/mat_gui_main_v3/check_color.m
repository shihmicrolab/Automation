function [  ] = check_color(handles, hObject)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

if get(handles.checkcolorRadiobutton,'Value') == 1
    
    electrode_number = str2double(get(hObject,'String'));
    
    drop = ColorDroplet.createObj(handles,electrode_number);
    
    drop.displayColor(handles,electrode_number);
    
    
end


end

