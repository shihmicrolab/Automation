function [  ] = implement_circle_sequence(handles )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

    % Getting information from the sequence table
    sequencetableData = get(handles.sequenceTable,'Data');
    
    % Getting information from the temp sequence table
    tempsequencetableData = get(handles.tempsequenceTable,'Data');
    
    % Getting the collumn increment info from handles
    
    handles = guidata(gcbo);
    
%     if handles.sequenceCollumnincrement >= 50
%         
%         errordlg('Maximum sequence set to 50','Error');
%         
%         msg = 'Maximum sequence set to 50';
%         
%         error(msg);
%         
%     end
    
    handles.sequenceCollumnincrement = handles.sequenceCollumnincrement + 1;
    
    guidata(gcbo,handles);
    
    % Setting the collumn increment text to new value
    
    set (handles.sequencecollumnincrementText,'String',int2str(handles.sequenceCollumnincrement)) ; 
    
    % Setting to sequence table (ABSORBANCE COMMAND)
    
   sequencetableData{1,handles.sequenceCollumnincrement} = 'C';
    
    % Saving information to the sequence table
    
    set(handles.sequenceTable,'Data',sequencetableData);
    
    % Re-Initializing the Temp Sequence table
    
    for i = 1:1:6
        
        tempsequencetableData {i,1} = '';
        
    end
    
    % Saving information to the temp sequence table
    set(handles.tempsequenceTable,'Data',tempsequencetableData);
    
    %Re-init the temp row sequence increment
    
    handles = guidata(gcbo);
        
    handles.tempsequenceRowincrement = 0 ;
    
    guidata(gcbo,handles);
    
    % Setting the buttons to "white"
    
    for i = 1:1:handles.grid_row
        for j = 1:1:handles.grid_collumn
            
            % Apparently, we do not have to leave out the ones that are not
            % suppose to be "visible"
            
            %if get(handles.Electrode_pad(i,j),'Visible') == 'off'
                
              %continue
                
           % end
            
            set(handles.Electrode_pad(i,j) ,'BackgroundColor','white');
            
            
        end
    end
    
    
end



