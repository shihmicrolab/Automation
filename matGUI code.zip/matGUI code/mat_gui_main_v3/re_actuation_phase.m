function [  ] = re_actuation_phase( hObject,handles,incrementedVoltage,j )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

disp_command(handles,'RE-ACTUATION PHASE INITITATED');

set(handles.phaseButton,'BackgroundColor','cyan','String','RE-ACTUATION PHASE','Fontweight','bold');

%Getting info from master Table

mastertableData = get(handles.masterTable,'Data');

%Getting info from temp Table

tempsequencetableData = get(handles.tempsequenceTable,'Data');


%Getting info from sequence Table

sequencetableData = get(handles.sequenceTable,'Data');

% Getting from the master table the number of electrode that failed
% and putting into the temp_array table those that you need to redo

number_of_electrode_failed = 0; 

counter = 0;

for i = 1:1:104
    
    if mastertableData(i,4) == 1
        
        counter = counter + 1;
        
        number_of_electrode_failed = number_of_electrode_failed + 1;
        
        tempsequencetableData{counter,2} = i;
        
        set(handles.tempsequenceTable,'Data',tempsequencetableData);
        
        % Setting those who are getting actuated (FOR the CHECKING PHASE LOOP)
        
        mastertableData (i,5) = 1;
        
    end
   
end

% Saving info to master table

set(handles.masterTable,'Data',mastertableData);


% Running sequence

%%% SETTING THE VOLTAGE TO BE BASE ONE %%% 

voltage_control( handles,str2double(get(handles.functionGbasevoltageEdittext,'String'))) ;
set(handles.functionGvoltageEdittext,'String',get(handles.functionGbasevoltageEdittext,'String'));

for current_number_actuation = 1:1:6
    
    if  tempsequencetableData{current_number_actuation,2} ~= 0
    
    electrode_number = tempsequencetableData{current_number_actuation,2} ;
    
    actuate_electrode_multiple_on_noij( electrode_number,handles,hObject );
    
    end
    
end

pause(handles.time_electrode);

for current_number_actuation = 1:1:6
    
    if  tempsequencetableData{current_number_actuation,2} ~= 0
    
    electrode_number = tempsequencetableData{current_number_actuation,2} ;
    
    actuate_electrode_multiple_off_noij( electrode_number,handles );    
    
    end
    
end

%%%%% CORRECTION TIME %%%%% (KEEPING THE VOLTAGE AT BASE VOLTAGE)

% If not the first collumn sequence
if j ~= 1
% Actuate previous electrode 
for i = 1:1:6
    
            
            if isempty(sequencetableData{i,j}) == 1
                
                continue
                
            end
            
            previous_electrode_number = sequencetableData{i,j-1};
            
            actuate_electrode_multiple_on_noij( previous_electrode_number,handles,hObject );
            
end

pause(str2double(get(handles.correctiontimeEdittext,'String')));

% Actuating the intended electrode (the one we want to go to)

for current_number_actuation = 1:1:6
    
    if  tempsequencetableData{current_number_actuation,2} ~= 0
    
    electrode_number = tempsequencetableData{current_number_actuation,2} ;
    
    actuate_electrode_multiple_on_noij( electrode_number,handles,hObject );
    
    end
    
end

pause(str2double(get(handles.correctiontimeEdittext,'String')));

% Turning off the previous electrode

for i = 1:1:6
            
            if isempty(sequencetableData{i,j}) == 1
                
                continue
                
            end
            
            previous_electrode_number = sequencetableData{i,j-1};
            
            actuate_electrode_multiple_off_noij( previous_electrode_number,handles );
            
end


% correctiontimeEdittext
end
%%%%% CORRECTION TIME %%%%%

%%%%% JOLT TIME %%%%%

%%% SETTING THE VOLTAGE TO BE MODIFIED ONE %%% (incremented inside the while checkstate == false loop)

voltage_control(handles, incrementedVoltage);
set(handles.functionGvoltageEdittext,'String',num2str(incrementedVoltage));

for current_number_actuation = 1:1:6
    
    if  tempsequencetableData{current_number_actuation,2} ~= 0
    
    electrode_number = tempsequencetableData{current_number_actuation,2} ;
    
    actuate_electrode_multiple_on_noij( electrode_number,handles,hObject );
    
    end
    
end

pause(str2double(get(handles.functionGjolttimeEdittext,'String')));

for current_number_actuation = 1:1:6
    
    if  tempsequencetableData{current_number_actuation,2} ~= 0
    
    electrode_number = tempsequencetableData{current_number_actuation,2} ;
    
    actuate_electrode_multiple_off_noij( electrode_number,handles );    
    
    end
    
end
%%%%% JOLT TIME %%%%%

%%% Re-Init the temp sequence table %%%

for i = 1:1:6
   
    tempsequencetableData{i,2} = '';
    
end

set(handles.tempsequenceTable,'Data',tempsequencetableData);

%%% Re-Init the master sequence table %%%

for i = 1:1:104
   
   mastertableData(i,4) = 0;
    
end

set(handles.masterTable,'Data',mastertableData);

disp('RE-ACTUATION PHASE TERMINATED');

end

