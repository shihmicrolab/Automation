function [  ] = color_electrode_pad( electrode_number,color_pad,handles )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

mastertableData = get(handles.masterTable,'Data');

i = mastertableData(electrode_number,6);

j = mastertableData(electrode_number,7);

set(handles.Electrode_pad(i,j),'Backgroundcolor',color_pad);

end

