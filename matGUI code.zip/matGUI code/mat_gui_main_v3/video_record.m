function [ ] = video_record( handles)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
%% Asking for filename for the video

% Prompt that asks user for the com of the arduino
prompt = {'Video Filename'};
dlg_title = 'Record Video ';
num_lines = 1;
defaultans = {''};
answer = inputdlg(prompt,dlg_title,num_lines,defaultans);

video_filename = cell2mat(answer);

%% Recording Video 

vid = handles.vid;

set(vid, 'FramesPerTrigger', Inf); 
set(vid, 'ReturnedColorspace', 'rgb'); 
vid.FrameRate =30; 
vid.FrameGrabInterval = 1; % distance between captured frames 
%start(vid)
aviVideo = VideoWriter(strcat(video_filename,'.avi')); % Create a new AVI file 
open(aviVideo); 
for iFrame = 1:100 % Capture 100 frames
    
  % Cancel Record here
  
  I=getsnapshot(vid); 
  F = im2frame(I); % Convert I to a movie frame 
  writeVideo(aviVideo,F); % Add the frame to the AVI file 
  disp(iFrame);
end 
close(aviVideo); % Close the AVI file 
%stop(vid);

end

