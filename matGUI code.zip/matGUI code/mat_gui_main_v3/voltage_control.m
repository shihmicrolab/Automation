function [] = voltage_control( handles,voltage2send )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

if voltage2send > 3.5
    
    handles.myFGen.Amplitude = 1;
    
else
    
    handles.myFGen.Amplitude = voltage2send;
    
end

end

