function [  ] = electrode_functions( hObject, eventdata, handles )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

% Checking which of the RadioButtons (Control) is "activated"

numbering_electrode( handles, hObject );

real_time_actuation( hObject, handles );

sequence_actuation( hObject, handles );

saving_coordinates_masterTable_single( handles,hObject );

single_check_electrode( handles, hObject );

check_color(handles, hObject);

save_coordinates_button( handles, hObject );

prototype_save_coordinates( handles,hObject );

end

