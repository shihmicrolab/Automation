function [  ] = load_coordinates( handles )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%Name of file we want to load
prompt = {'Load: '};
dlg_title = 'Load coordinates';
num_lines = 1;
defaultans = {'name'};
answer = inputdlg(prompt,dlg_title,num_lines,defaultans);

answer_text = cell2mat(answer);

filename = answer_text;

x_y_coordinates = load(filename);

%Sending numbers to sequence table
% disp(sequencerData.sequencetableData{1,1});

%Getting data from sequence table
mastertableData = (get(handles.masterTable,'Data'));

for i=1:1:104
    
    mastertableData(i,2) = x_y_coordinates.saved_coordinates(i,1);
    mastertableData(i,3) = x_y_coordinates.saved_coordinates(i,2);
    
end

set(handles.masterTable,'Data',mastertableData);

end

