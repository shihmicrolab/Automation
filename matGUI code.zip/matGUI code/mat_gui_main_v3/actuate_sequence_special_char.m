function [  ] = actuate_sequence_special_char( handles,hObject,sequenceStep)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%% Initializing

tic;

%% General Initializing

set(handles.phaseButton,'BackgroundColor','green','String','ACUTATION PHASE','Fontweight','bold');

%%% ACTIVATE_SEQUENCE_CODE %%%

disp_command(handles,'Sequence Activated');

handles = guidata(gcbo);

counter = 0 ;

j = 0;

% Getting information from the sequence table
sequencetableData = get(handles.sequenceTable,'Data');

%% Actuate Sequence

while counter ~= sequenceStep %+ 1
    
    counter = counter + 1 ;
    
    j = j + 1;
    
    % Setting the increment string to "activated" collumn
    
    set(handles.sequencecollumnincrementText,'String',int2str(j));
    
    handles = guidata(gcbo);
    
    % Checking if user press the cancel button
    
    cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');
    
    if cancelsequence_flag == 1
        
        set(handles.cancelsequenceButton,'UserData',0);
        
        break
        
    end
    
    %% Checking for Special characters
    
    [ continue_statement ] = special_character_in_sequence_no_abs( handles,j);
    
    if continue_statement == true
        
        continue
        
    end
    

    
    %% Electrode Actuating
    
    % Read the value of table and actuate the electrode
    
    for i = 1:1:20
        
        if isempty(sequencetableData{i,j}) == 1
            
            continue
            
        end
        
        %Turning electrode ON
        
        electrode_number = sequencetableData{i,j};
        
        actuate_electrode_multiple_on_noij( electrode_number,handles,hObject );
        
    end
    
    
    pause(str2double(get(handles.timeEdittext,'String')));
    
    
    for i = 1:1:20
        
        if isempty(sequencetableData{i,j}) == 1
            
            continue
            
        end

        %Turning electrode OFF
        
        electrode_number = sequencetableData{i,j};
        
        actuate_electrode_multiple_off_noij( electrode_number,handles );
        
    end
    
end
    

%% End of Sequence Operations

% Display that sequence is done

disp_command(handles,'Sequence Terminated');

% Setting the increment text back to 0

set(handles.sequencecollumnincrementText,'String','0');

% Set phase state

set(handles.phaseButton,'BackgroundColor','white','String','STAND-BY','Fontweight','bold');

end

