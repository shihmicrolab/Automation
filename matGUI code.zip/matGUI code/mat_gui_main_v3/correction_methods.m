function [  ] = correction_methods(hObject,handles,counter,increasedVoltage )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

if get(handles.correctionjoltRadiobutton,'Value') == 1
    
    correction_jolt( hObject,handles,increasedVoltage,counter);
    
elseif get(handles.joltonlyRadiobutton,'Value') == 1
    
    jolt_only( hObject,handles,increasedVoltage);
    
elseif get(handles.correctiononlyRadiobutton,'Value') == 1
   
    correction_only( hObject,handles,counter);
    
elseif get(handles.normalreactuationRadiobutton,'Value') == 1
    
    normal_reactuation( hObject,handles);
    
end


end

