function [ address] = conversion_2_arduino_address( handles , electrode_number )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

if electrode_number < 21 
    address = handles.max_3;
    
  
  elseif electrode_number > 20 && electrode_number < 41 
    address = handles.max_4;
    
    
  elseif electrode_number > 40 && electrode_number < 61 
    address = handles.max_5;
    
  
    
  elseif electrode_number > 60 && electrode_number < 81
    address = handles.max_6;
    
  
    
  elseif electrode_number > 80 && electrode_number < 101
    address = handles.max_1;
    
  
  else
    address = handles.max_2;
    
  
end

end