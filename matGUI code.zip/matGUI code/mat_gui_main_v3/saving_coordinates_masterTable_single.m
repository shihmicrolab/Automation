function [ ] = saving_coordinates_masterTable_single( handles,hObject )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

if get(handles.saveidRadiobutton,'Value') == 1
    
disp_command(handles,'Saving ID activated');

%Getting information from the master table

mastertableData = get (handles.masterTable,'Data');

% Getting the electrode number info 

a = 'electrode_' ; 

% the actuation number
b =  cell2mat(get(hObject,'String'));

s = strcat(a,b);

my_struct = evalin('base',s);

% Getting the x & y coordinate

position_x = my_struct.Position(1);

position_y = my_struct.Position(2);

% Getting the acuation number to know where to store the x_y coordinate in
% the master Table

% Setting position x into the table

% Since we are getting the 'upper-left' corner -> we have to calculate the
% 'middle' -> Matlab pixel range (upper left = 1,1) (downards right = max,max)

% This might be inaccurate if the image is 'slanted' (ie. every electrode dont have same 'dimensions')



mastertableData(str2double(b),2) = position_x + str2double(get(handles.electrodedimensionEdittext,'String'))/2 ;

mastertableData(str2double(b),3) = position_y + str2double(get(handles.electrodedimensionEdittext,'String'))/2 ;

set(handles.masterTable,'Data',mastertableData);

end

end



