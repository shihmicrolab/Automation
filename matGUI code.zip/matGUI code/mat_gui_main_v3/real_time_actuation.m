function [  ] = real_time_actuation( hObject, handles )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

if get(handles.realtimeRadiobutton,'Value') == 1
    
    disp_command(handles,'Real_time Actuation activated');
    
    %If user wants to cancel
    if get(hObject,'UserData') == 1
        
       set(hObject,'UserData',0);
       set(hObject,'Backgroundcolor','white');
       
    else

    % Setting the value of the electrode (pushbutton) -> 1
    
    set(hObject,'UserData',1);
    
    set(hObject,'Backgroundcolor','cyan');
    
    end
     
end



end

