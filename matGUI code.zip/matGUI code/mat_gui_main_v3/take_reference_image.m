function [  ] = take_reference_image(  )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

handles = guidata(gcbo);

sum_reference_image = zeros(1024,1280);

avg_reference_image = zeros(1024,1280);

h = waitbar(0,'1','Name','Calibrating Reference Image');
steps = 5;
for step = 1:steps
    % computations take place here
    
    reference_image = im2double(rgb2gray(getsnapshot(handles.vid)));
    sum_reference_image = reference_image + sum_reference_image;
    
    waitbar(step/steps,h,strcat(int2str(step),'%'));
    pause(0.25);
end
close(h)

avg_reference_image = im2uint8(sum_reference_image / 5);

handles.avg_reference_image = avg_reference_image;

guidata(gcbo,handles);

%Showing the picture inside the axes
imshow(handles.avg_reference_image,'Parent',handles.referencepicAxe);

figure('Name','Average Reference Image','NumberTitle','off');

imshow(uint8(avg_reference_image));

figure('Name','Reference Image','NumberTitle','off');
imshow(reference_image);


end

