function [ ] = save_image(imagedata,name,step,reactuation_flag,countNumReactuations)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

stepstr = int2str(step);

if reactuation_flag == 0
    
filename = strcat(name,'_',stepstr,'.png');

end

if reactuation_flag == 1
    
  countNumReactuationsStr =   int2str(countNumReactuations);
    
filename = strcat(name,'_',stepstr,'_R',countNumReactuationsStr,'.png');

end

imwrite(imagedata,filename);

end

