function [ ] = load_sequencerdata2sequencetable( handles,step)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%Getting data from sequencer table
sequencertableData = (get(handles.sequencerTable,'Data'));

%Name of file we want to load
sequencerFilename = sequencertableData{1,step};

sequencerData = load(strcat('sequence_',sequencerFilename));

%Sending numbers to sequence table
disp(sequencerData.sequencetableData{1,1});

%Getting data from sequence table
%sequencetableData = (get(handles.sequenceTable,'Data'));

sequencetableData = sequencerData.sequencetableData;

set(handles.sequenceTable,'Data',sequencetableData);

end
