function [ ] = init_max_I2C( Max_object )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  writeRegister(Max_object,4,1);

%  //set ports in output mode (all of them)

  writeRegister(Max_object,9,85); 
  writeRegister(Max_object,10,85);
  writeRegister(Max_object,11,85);
  writeRegister(Max_object,12,85);
  writeRegister(Max_object,13,85);
  writeRegister(Max_object,14,85);
  writeRegister(Max_object,15,85);

end
