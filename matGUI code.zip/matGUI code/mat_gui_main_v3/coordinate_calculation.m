function [ x_electrode, y_electrode ] = coordinate_calculation(i_electrode , j_electrode ,i_reference, j_reference, x_reference , y_reference , electrode_dimension )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

%% I is suppose to correspond to Y & J is suppose to correspond to X


%% Calcualtion for the x coordinate

if j_electrode <= j_reference
x_electrode = x_reference - ((j_reference - j_electrode)*electrode_dimension) ; 

elseif j_electrode >= j_reference
x_electrode = x_reference + ((j_electrode - j_reference)*electrode_dimension) ; 
end

%% Calculation for the y electrode

if i_electrode <= i_reference
y_electrode = y_reference - ((i_reference - i_electrode)*electrode_dimension) ; 

elseif i_electrode >= i_reference
y_electrode = y_reference + ((i_electrode - i_reference)*electrode_dimension) ; 
end


end

