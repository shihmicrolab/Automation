%% Setup uEye

imaqhwinfo

info = imaqhwinfo('winvideo')

dev_info = imaqhwinfo('winvideo',1)

vid = videoinput('winvideo',1,'RGB32_1280x1024') ;
%%
preview(vid);
%% Take Reference Picture

figure('Name','Reference Picture','NumberTitle','off');

clear_reference_image = rgb2gray(getsnapshot(vid ));

imshow(clear_reference_image)

%% Take Comparison Picture

%figure('Name','Comparison Picture','NumberTitle','off');

compared_image = rgb2gray(getsnapshot(vid ));

imshow(compared_image);

%% Manipulation of Pictures (transformations) (edit here)

transformed_reference_image = imsharpen(clear_reference_image);

transformed_compared_image = imsharpen(compared_image);


%% Different it

figure('Name','Difference Picture','NumberTitle','off');

difference_image = imabsdiff(transformed_reference_image,transformed_compared_image);

imshow(difference_image);

%% Binarize it

difference_image_binary = imbinarize(difference_image);

imshow(difference_image_binary) ;


%% FIND CIRCLES ON THE BINARIZED IMAGE

% Radius of Circle

d = imdistline;

%% Deleting the radius

delete(d);

%% First attempt at finding circles

% Here you change the radius
% Since the 'circle' are white, then circle is brighter than the bacground,
% black.

[centers, radii] = imfindcircles(compared_image,[130 135],'ObjectPolarity','dark','Sensitivity',0.9965);

imshow(compared_image);

h = viscircles(centers,radii);

%% Second attempt at finding circles

[centers, radii] = imfindcircles(difference_image_binary,[130 135],'ObjectPolarity','bright','Method','twostage','Sensitivity',0.995);

delete(h);

imshow(difference_image_binary);

h = viscircles(centers,radii);
