function [  ] = prototype_save_coordinates( handles,hObject )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

if get(handles.prototypesavecoordinateRadiobutton,'Value') == 1
    
    mastertableData = get(handles.masterTable,'Data');
    
    switch get(handles.referenceelectrodeTogglebutton,'Value') == 1
        
        case 1
            
            electrode_number = str2double(get(hObject,'String'));
            electrodeDimension = str2double(get(handles.electrodedimensionEdittext,'String'));
            
            i_reference = mastertableData(electrode_number,6);
            j_reference = mastertableData(electrode_number,7);
            
            set(handles.inumberreferenceEdittext,'String',int2str(i_reference));
            set(handles.jnumberreferenceEdittext,'String',int2str(j_reference));
            
            prompt = {'X reference','Y reference'};
            dlg_title = 'Saving Reference Coordinate';
            num_lines = 1;
            defaultans = {'0','0'};
            answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
            
            x_reference = str2double(cell2mat(answer(1)));
            y_reference = str2double(cell2mat(answer(2)));
            
            set(handles.xreferencenumberEdittext,'String',int2str(x_reference));
            set(handles.yreferencenumberEdittext,'String',int2str(y_reference));
            
            x_reference_center = x_reference + (electrodeDimension/2);
            
            y_reference_center = y_reference + (electrodeDimension/2);
            
            mastertableData(electrode_number,2) = x_reference_center;
            mastertableData(electrode_number,3) = y_reference_center;
            
            set(handles.masterTable,'Data',mastertableData);
            
            
        case 0
            
            % Does the calculation and saves the coordinate into the table
            % Use the reference as source of information for calculations
            % ...
            
            electrode_number = str2double(get(hObject,'String'));
            i_electrode = mastertableData(electrode_number,6);
            j_electrode = mastertableData(electrode_number,7);
            
            i_reference = str2double(get(handles.inumberreferenceEdittext,'String'));
            j_reference = str2double(get(handles.jnumberreferenceEdittext,'String'));
            x_reference = str2double(get(handles.xreferencenumberEdittext,'String'));
            y_reference = str2double(get(handles.yreferencenumberEdittext,'String'));
            electrodeDimension = str2double(get(handles.electrodedimensionEdittext,'String'));
            
            [ x_electrode, y_electrode ] = coordinate_calculation(i_electrode , j_electrode ,i_reference, j_reference, x_reference , y_reference , electrodeDimension );
            
            %% Calculate the center x & y
            
            x_electrode_center = x_electrode + (electrodeDimension/2);
            
            y_electrode_center = y_electrode + (electrodeDimension/2);
            
            mastertableData(electrode_number,2) = x_electrode_center;
            mastertableData(electrode_number,3) = y_electrode_center;

            set(handles.masterTable,'Data',mastertableData);

    end
    
end

end

