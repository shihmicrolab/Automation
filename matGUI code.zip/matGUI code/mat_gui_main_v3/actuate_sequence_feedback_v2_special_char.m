function [  ] = actuate_sequence_feedback_v2_special_char( hObject, handles,step_sequence )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

%inputs -> step_sequence
%output -> time it took

% record time
% gather sequence table data / master table data
% start sequence
% (have in mind that mutliple could be turned on on one step)
% note the one that turns on -> save it in master table data
% detection -> output = fail / success
% correction measure -> depending on user radio button.
% stop sequence
% record time
% output useful information -> (# step / step fail / recorded time / voltage / frequencey / velocity / % completition /correciton method )
% reinitialize everything for next run

%%%SETUP%%%

tic;

sequencetableData = get(handles.sequenceTable,'Data');

mastertableData = get(handles.masterTable,'Data');

counter = 0;

break_all = 0;

fail_counter = 0; % # time it failed

if get(handles.circleRadiobutton,'Value') == 1
    
    detection = 'circle';
    
elseif  get(handles.blobRadiobutton,'Value') == 1
    
    detection = 'blob';
    
end

%%%ACTIVATE SEQUENCE%%%

while counter ~= step_sequence
    
    counter = counter +1;
    
    set(handles.sequencecollumnincrementText,'String',int2str(counter));
    
    cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');
    
    if cancelsequence_flag == 1
        
        disp_command(handles,'Cancelling Operation...');
        
        cancelsequence_flag = 0;
        
        set(handles.cancelsequenceButton,'UserData',cancelsequence_flag);
        
        break
        
    end
    
    %% Checking for Special characters
    
    [ continue_statement ] = special_character_in_sequence_no_abs( handles,counter);
    
    if continue_statement == true
        
        continue
        
    end
    
    %%
    
    %TURN ON
    
    for i = 1:1:20
        
        if isempty(sequencetableData{i,counter}) == 1
            
            continue
            
        end
        
        electrode_number = sequencetableData{i,counter};
        
        actuate_electrode_multiple_on_noij( electrode_number,handles,hObject );
        
        mastertableData(electrode_number,5) = 1;
        
    end
    
    pause(str2double(get(handles.timeEdittext,'String')));
    
    set(handles.masterTable,'Data',mastertableData);
    
    %TURN OFF
    
    for i = 1:1:20
        
        if isempty(sequencetableData{i,counter}) == 1
            
            continue
            
        end
        
        electrode_number = sequencetableData{i,counter};
        
        actuate_electrode_multiple_off_noij( electrode_number,handles );
        
    end
    
    if get(handles.feedbackTogglebutton,'Value') == 1
        
        %DETECTION PHASE
        
        switch (detection)
            
            case 'circle'
                
                check_state = checking_phase( handles,counter );
                
            case 'blob'
                
                check_state = checking_phase_blob( handles,counter );
                
        end
        
        %CORRECTION PHASE
        
        correction_attempt_counter = 0; % # of attempt at correcting it (init)
        
        while check_state == false
            
            fail_counter = fail_counter + 1; % Counting # time it failed
            
            correction_attempt_counter = correction_attempt_counter + 1; % # of attempt at correcting it
            
            %Increase Voltage
            currentVoltage = str2double(get(handles.functionGvoltageEdittext,'String'));
            increasedVoltage = currentVoltage + str2double(get(handles.joltvEdittext,'String'));
            
            if str2double(get(handles.functionGvoltageEdittext,'String')) > 3.5
                
                break_all = 1;
                break
                
            elseif correction_attempt_counter > 15 % Break if more than 15 attempts
                
                disp('More than 15 attempts therefore we break out');
                
                break_all = 1;
                break
                
            end
            
            cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');
            
            if cancelsequence_flag == 1
                
                disp_command(handles,'Cancelling Operation...');
                
                break
                
            end
            
            %CORRECTION METHOD
            correction_methods(hObject,handles,counter,increasedVoltage);
            
            %DETECTION AGAIN
            switch (detection)
                
                case 'circle'
                    
                    check_state = checking_phase( handles,counter );
                    
                case 'blob'
                    
                    check_state = checking_phase_blob( handles,counter );
                    
            end
            
        end
        
        if break_all == 1
            
            break
            
        end
        
    end
    
    %Have to reinit the voltage to base voltage
    voltage_control( handles,str2double(get(handles.functionGbasevoltageEdittext,'String'))) ;
    set(handles.functionGvoltageEdittext,'String',get(handles.functionGbasevoltageEdittext,'String'));
    
    %Reinitialize stuff
    mastertableData = get(handles.masterTable,'Data');
    tempsequencetableData = get(handles.tempsequenceTable,'Data');
    
    for i = 1:1:104
        
        mastertableData(i,4) = 0 ;
        mastertableData(i,5) = 0 ;
        
    end
    
    for i = 1:1:20
        
        tempsequencetableData{i,2} = '';
        
    end
    
    set(handles.masterTable,'Data',mastertableData);
    set(handles.tempsequenceTable,'Data',tempsequencetableData);
    
end

%%%ENDING SEQUENCE%%%

realtimeon = toc;
set(handles.realtotaltimeonStatictext,'String',int2str(realtimeon));
set(handles.laststeponStatictext,'String',int2str(counter));
disp_command(handles,'Sequence Terminated');

disp('Sequence Time :');
disp(realtimeon);
disp('Last Step on :');
disp(counter);
disp('# Time Failed total :')
disp(fail_counter);

%%%REINIT FOR NEXT RUN%%%

%Have to reinit the voltage to base voltage
voltage_control( handles,str2double(get(handles.functionGbasevoltageEdittext,'String'))) ;
set(handles.functionGvoltageEdittext,'String',get(handles.functionGbasevoltageEdittext,'String'));

set(handles.sequencecollumnincrementText,'String','0');
mastertableData = get(handles.masterTable,'Data');
tempsequencetableData = get(handles.tempsequenceTable,'Data');

for i = 1:1:104
    
    mastertableData(i,4) = 0 ;
    mastertableData(i,5) = 0 ;
    
end

for i = 1:1:20
    
    tempsequencetableData{i,2} = '';
    
end

set(handles.masterTable,'Data',mastertableData);
set(handles.tempsequenceTable,'Data',tempsequencetableData);

set(handles.phaseButton,'BackgroundColor','white','String','STAND-BY','Fontweight','bold');
end



