function [ continue_statement, absorbancevalue_Counter, counter4time, time_counter,luxvaluesData,check_OD_value ] = special_character_in_sequence( handles,luxvaluesData,j,absorbancevalue_Counter,counter4time,time_counter,number2Average )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

%% Getting tables Data

absorbancetableData = get(handles.absorbanceTable,'Data');

sequencetableData = get(handles.sequenceTable,'Data');

luxtableData = get(handles.luxTable,'Data');


%% Special Characters here

if ischar(sequencetableData{1,j}) == 1
    
    if sequencetableData{1,j} == 'T' % Paused Time
        
        pause(str2double(sequencetableData{2,j}));
        
        continue_statement = true;
        
    elseif sequencetableData{1,j} == 'O' % Blank OD reading
        
        blankValue = get_absorbance_value(handles);
        %blankValue = 1000;
        
        set(handles.blankluxEdittext,'String',num2str(blankValue));
        
        continue_statement = true;
        
    elseif sequencetableData{1,j} == 'V' % Voltage Change
        
        voltage2send = str2double(sequencetableData{2,j});
        
        set(handles.functionGvoltageEdittext,'String',sequencetableData{2,j});
        
        voltage_control( handles,voltage2send );
        
        continue_statement = true;
        
    elseif sequencetableData{1,j} == 'AT' % Acutation Time Change
        
        actuation_time = str2double(sequencetableData{2,j});
        
        set(handles.timeEdittext,'String',num2str(actuation_time));
        
        continue_statement = true;
        
    elseif sequencetableData{1,j} == 'A' % OD reading
        
        % Absorbance Value -> is really just Lux (should be FIXED)
        
        absorbancevalue_Counter = absorbancevalue_Counter + 1;
        
        absorbanceValue = get_absorbance_value(handles);
        %absorbanceValue = 150;
       
        luxtableData{absorbancevalue_Counter,1} = absorbanceValue;
        luxtableData{absorbancevalue_Counter,2} = toc;
        
        set(handles.luxTable,'Data',luxtableData);
        
        absorbance_value_text = strcat('Absorbance Value: ',num2str(absorbanceValue));
        
        disp_command(handles,absorbance_value_text);
        
        luxvaluesData(absorbancevalue_Counter,1) = absorbanceValue;
        
        counter4time = counter4time + 1 ;
        
        % Input the time it was recorded
        
        if mod(counter4time,number2Average) == 0
            
            time_counter = time_counter + 1;
            
            absorbancetableData {time_counter,3} = toc;
            
            set(handles.absorbanceTable,'Data',absorbancetableData);
            
            % Input the Lux and OD also
            
            summingLuxTemp = 0;
            
            for k = 0:1:number2Average - 1
                
                summingLuxTemp = luxvaluesData(absorbancevalue_Counter - k,1) + summingLuxTemp;
                
            end
            
            % Average the Lux
            
            averageLuxTemp_send = summingLuxTemp/number2Average;
            
            absorbancetableData {time_counter,1} = averageLuxTemp_send;
            
            % output the OD
            
            absorbancetableData {time_counter,2} = lux_2_OD( str2double(get(handles.blankluxEdittext,'String')),averageLuxTemp_send );
            
            check_OD_value = lux_2_OD( str2double(get(handles.blankluxEdittext,'String')),averageLuxTemp_send );
            
            disp_command(handle,strcat('OD Value : ',num2str(check_OD_value)));
            
            set(handles.absorbanceTable,'Data',absorbancetableData);
            
            %         % Sending values to Live Graph
            %
            %         % OD value to send
            %
            %         odValueGraph = lux_2_OD( str2double(get(handles.blankluxEdittext,'String')),averageLuxTemp_send );
            %
            %         % Get current time
            %         t =  datetime('now') - startTime;
            %
            %         % Add points to animation
            %         addpoints(odLine,datenum(t),odValueGraph);
            %
            %         % Update axes
            %         ax.XLim = datenum([t-seconds(15) t]);
            %         datetick('x','keeplimits');
            %         drawnow;
            
        end
        
        continue_statement = true;
        
    else
        
        continue_statement = false;
        
    end
    
else
    
    continue_statement = false;
    
end

end

