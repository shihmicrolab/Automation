function [  ] = space_key_pressed_functions( handles,hObject )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

% Looking at which Radio Button is turned 'On'

space_real_time_actuation( handles,hObject );

space_sequence_actuation( handles,hObject );


end

