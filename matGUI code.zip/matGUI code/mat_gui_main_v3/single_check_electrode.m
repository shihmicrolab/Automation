function [  ] = single_check_electrode( handles, hObject )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

if get(handles.checksingleelectrodeRadiobutton,'Value') == 1
    
    disp_command(handles,'Checking Electrode');
    
    % Taking the comparison image

    compare_image = rgb2gray(getsnapshot(handles.vid ));

    difference_image = imabsdiff(handles.reference_image,compare_image);

    difference_image_binary = imbinarize(difference_image);
    
    %Showing the picture inside the axes
    imshow(difference_image_binary,'Parent',handles.comparepicAxe);

    % Getting the electrode number 
    electrode_number = str2double(get(hObject,'String'));
   
    % Getting info from master table
    
    mastertableData = get(handles.masterTable,'Data');
    
    % Getting the position x_y
        
        position_x = mastertableData(electrode_number,2);
        
        position_y = mastertableData(electrode_number,3);
        
    %%% Squaring it
        
        position_x_t = position_x - 6;
        
        position_y_t = position_y - 5;
        
        
        
        %%% This is where you make the square (size of it) (Electrode ID)
        for i_s = 1:1:9
            for j_s = 1:1:12
                
                sum_electrode = difference_image_binary (position_y_t + i_s , position_x_t + j_s  ) + sum_electrode ;
                
            end
        end
    
        c = 'Electrode ' ;
        d =  int2str(electrode_number);
        
        s2 = strcat(c,d);
        
        %%% Telling which electrode worked
        
        if sum_electrode == 108
            
            disp_command(handles,s2);
            disp_command(handles,'worked');
            
        else
            
            disp_command(handles,s2);
            disp_command(handles,'failed');
            
        end
    
    
    
end

end

