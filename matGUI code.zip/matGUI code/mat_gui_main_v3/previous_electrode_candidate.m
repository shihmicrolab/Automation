function [ previousElectrode_candidate ] = previous_electrode_candidate( handles,i,j )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%% Testing

previousElectrode_candidate = zeros(4);

electrode_failed = str2double(get(handles.Electrode_pad(i,j),'String'));

max_i = size(handles.Electrode_pad,1);
max_j = size(handles.Electrode_pad,2);

candidate_1 = [i-1 j];
candidate_2 = [i j-1];
candidate_3 = [i+1 j];
candidate_4 = [i j+1];

if candidate_1(1) <= max_i && candidate_1(2) <= max_j && candidate_1(1) ~= 0 && candidate_1(2) ~= 0
previousElectrode_candidate(1) = str2double(get(handles.Electrode_pad(candidate_1(1),candidate_1(2)),'String'));
end
if candidate_2(1) <= max_i && candidate_2(2) <= max_j && candidate_2(1) ~= 0 && candidate_2(2) ~= 0
previousElectrode_candidate(2) = str2double(get(handles.Electrode_pad(candidate_2(1),candidate_2(2)),'String'));
end
if candidate_3(1) <= max_i && candidate_3(2) <= max_j && candidate_3(1) ~= 0 && candidate_3(2) ~= 0
previousElectrode_candidate(3) = str2double(get(handles.Electrode_pad(candidate_3(1),candidate_3(2)),'String'));
end
if candidate_4(1) <= max_i && candidate_4(2) <= max_j && candidate_4(1) ~= 0 && candidate_4(2) ~= 0
previousElectrode_candidate(4) = str2double(get(handles.Electrode_pad(candidate_4(1),candidate_4(2)),'String'));
end

disp(strcat(num2str(electrode_failed),' : has these neighbour'))

for step=1:1:4
    
    if previousElectrode_candidate(step) ~= 0
        
        disp(previousElectrode_candidate(step));
        
    end
    
end

end

