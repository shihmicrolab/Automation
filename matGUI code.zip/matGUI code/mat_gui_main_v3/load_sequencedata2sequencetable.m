function [ ] = load_sequencedata2sequencetable( handles)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%Name of file we want to load

prompt = {'Load sequence: '};
            dlg_title = 'Load sequence';
            num_lines = 1;
            defaultans = {'sequence_'};
            answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
            
            sequenceFilename = cell2mat(answer);


sequenceData = load(sequenceFilename);

%Sending numbers to sequence table
% disp(sequencerData.sequencetableData{1,1});

%Getting data from sequence table
%sequencetableData = (get(handles.sequenceTable,'Data'));

sequencetableData = sequenceData.sequencetableData;

set(handles.sequenceTable,'Data',sequencetableData);

end

