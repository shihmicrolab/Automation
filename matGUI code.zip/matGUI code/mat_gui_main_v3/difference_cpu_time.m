function [ currentTime ] = difference_cpu_time()
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

 currentTime = toc;
 
 %difference_time = currentTime - startTime ;

end

