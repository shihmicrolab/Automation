classdef ColorDroplet
    %UNTITLED Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        RedVal
        GreenVal
        BlueVal
        
        GrayVal
    end
    
    % https://www.mathworks.com/help/matlab/matlab_oop/a-class-code-listing.html
    
    methods
        function obj = ColorDroplet(handles,image,gray_image,electrode_number)
            % using this website as reference (http://www.rapidtables.com/web/color/RGB_Color.htm#rgb-format)
            % image object -> imObj(1,1,3) -> (x,y,[R G B])
            % using the detection box, we make the color detection box
            % average the values of R G B -> avgR avgG avgB -> average
            % color
            
            % Reading the image in
            imageAnalyze = image;
            
            gray_imageAnalyze = gray_image;
            
            %Getting MasterTable Data
            mastertableData = get(handles.masterTable,'Data');
            
            % Getting the position x_y
            position_x = mastertableData(electrode_number,2);
            
            position_y = mastertableData(electrode_number,3);
            
            %Getting information on the size of the electrode
            
            electrodeDimension = str2double(get(handles.electrodedimensionEdittext,'String'));
            %%% Squaring it (Detection Square)
            % if the divider (electrodeDimension/divider) is a pair number
            % -> electrode dimension should be pair too (vice versa for impair numbers)
            position_x_min = position_x - (electrodeDimension/2);
            
            position_y_min = position_y - (electrodeDimension/2);
            
            position_x_max = position_x + (electrodeDimension/2);
            
            position_y_max = position_y + (electrodeDimension/2);
                 
            %% COLOR METHOD
            % Initialize the colorSum
            redValSum= 0 ;
            greenValSum= 0;
            blueValSum= 0;
            
            % Taking the average
            % Red values
            
            % PROBLEM, I KEEP GETTING 255 as redValSum -> because
            % imageAnalyze (x,y,1) returns -> unit8
            % we have to convert it to double
            
            % Dont know why but image(x,y,#) -> Error (the x and y are
            % inverted here).
            
            for x = position_x_min:1:position_x_max
                for y = position_y_min:1:position_y_max
                    
                    redValSum = imageAnalyze(y,x,1) + redValSum;
                    
                end
            end
            
            % Green values
            for x = position_x_min:1:position_x_max
                for y = position_y_min:1:position_y_max
                    
                    greenValSum = imageAnalyze(y,x,2) + greenValSum;
                    
                end
            end
            
            % Blue values
            for x = position_x_min:1:position_x_max
                for y = position_y_min:1:position_y_max
                    
                    blueValSum = imageAnalyze(y,x,3) + blueValSum;
                    
                end
            end
            
            xDistance = (position_x_max - position_x_min) + 1;
            yDistance = (position_y_max - position_y_min) + 1;
            valAvg = xDistance * yDistance;
            
            redValAvg = redValSum / valAvg;
            greenValAvg = greenValSum / valAvg;
            blueValAvg = blueValSum / valAvg;
            
            obj.RedVal = redValAvg;
            obj.GreenVal = greenValAvg;
            obj.BlueVal = blueValAvg;
            
            %            obj(5,5) = ColorDroplet;
            
            
            %% GRAY METHOD
            
            % Initialize the colorSum
            grayValSum= 0 ;
            
            % Taking the average
            
            
            % PROBLEM, I KEEP GETTING 255 as redValSum -> because
            % imageAnalyze (x,y,1) returns -> unit8
            % we have to convert it to double
            
            % Dont know why but image(x,y,#) -> Error (the x and y are
            % inverted here).
            
            for x = position_x_min:1:position_x_max
                for y = position_y_min:1:position_y_max
                    
                    grayValSum = gray_imageAnalyze(y,x) + grayValSum;
                    
                end
            end
            
            xDistance = (position_x_max - position_x_min) + 1;
            yDistance = (position_y_max - position_y_min) + 1;
            valAvg = xDistance * yDistance;
            
            grayValAvg = grayValSum / valAvg;
            
            obj.GrayVal = grayValAvg;
            
            
            %            obj(5,5) = ColorDroplet;
        end
        
        
        
        function displayColor(obj,handles,electrode_number)
            %displaying the color inside a figure (for user confirmation)
            
            disp(strcat('Electrode number:  ',int2str(electrode_number)));
            disp(strcat('Red:  ',num2str(obj.RedVal*255)));
            disp(strcat('Green:  ',num2str(obj.GreenVal*255)));
            disp(strcat('Blue:  ',num2str(obj.BlueVal*255)));
            disp('///////////////////////////////////////////');
            disp(obj.RedVal);
            disp(obj.GreenVal);
            disp(obj.BlueVal);
            
            %delete rectangleColor;
            %figure('Name','Measured Data');
            %viscircles(handles.colorAxe,[5 5],5,'Color',[obj.RedVal obj.GreenVal obj.BlueVal],'LineWidth',50);
            rectangleColor = rectangle(handles.colorAxe,'Facecolor',[obj.RedVal obj.GreenVal obj.BlueVal]);
            
            disp(strcat('Electrode number:  ',int2str(electrode_number)));
            disp(strcat('Gray:  ',num2str(obj.GrayVal*255)));
            disp('///////////////////////////////////////////');
            
            %delete rectangleColor;
            %figure('Name','Measured Data');
            %viscircles(handles.colorAxe,[5 5],5,'Color',[obj.RedVal obj.GreenVal obj.BlueVal],'LineWidth',50);
            %rectangleColor = rectangle(handles.colorAxe,'Facecolor',[1 1 1]);
            
        end
    end
    
    methods (Static)
        function obj = createObj(handles,electrode_number)
            %Creating object based on electrode_number
            
            image = im2double(getsnapshot(handles.vid )); %real
            
            %image = im2double(imread('15%JUL25_Colord.jpg')); %test
            
            gray_image = im2double(rgb2gray(getsnapshot(handles.vid ))); %real
            
            %gray_image = im2double(rgb2gray(imread('15%JUL25_Colord.jpg'))); %test
            
            obj = ColorDroplet(handles,image,gray_image,electrode_number);
        end
    end
    
end
