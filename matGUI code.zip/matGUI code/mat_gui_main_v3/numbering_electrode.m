function [  ] = numbering_electrode( handles, hObject )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

% Checking for the numbering toggle value

if get(handles.numberingRadiobutton,'Value') == 1
    
    disp_command(handles,'Numbering Electrode');
    
    set(hObject,'Backgroundcolor','black');
    
    %Asking the user for the electrode number
    prompt = {'Electrode Number :'};
    dlg_title = 'Numbering Electrode ';
    num_lines = 1;
    defaultans = {'0'};
    answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
    
    electrode_number_str = cell2mat(answer);
    
    
    
    % Setting the number of that electrode to electrode_number
    
    set (hObject,'String',electrode_number_str,'FontSize',15,'FontWeight','bold','ForegroundColor','white');
    
end

end

