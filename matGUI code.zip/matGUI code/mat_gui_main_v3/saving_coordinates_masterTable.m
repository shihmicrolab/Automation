function [  ] = saving_coordinates_masterTable( handles )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

%Getting information from the master table

mastertableData = get (handles.masterTable,'Data');

for i = 1:1:104

    if mastertableData(i,1) == 0
        
        continue
        
    end
    
% Getting the electrode number info 

a = 'electrode_' ; 

% MAY CHANGE HERE, (inside a for loop) (look at who is "set") (then set the
% b - > actuation number) %
b =  int2str(mastertableData(i,1)) ; 
% MAY CHANGE HERE, (inside a for loop) (look at who is "set") (then set the
% b - > actuation number) %

s = strcat(a,b);

my_struct = evalin('base',s);

% Getting the x & y coordinate

position_x = my_struct.Position(1);

position_y = my_struct.Position(2);

% Getting the acuation number to know where to store the x_y coordinate in
% the master Table

% Setting position x into the table

% Since we are getting the 'upper-left' corner -> we have to calculate the
% 'middle' -> Matlab pixel range (upper left = 1,1) (downards right = max,max)

% This might be inaccurate if the image is 'slanted' (ie. every electrode dont have same 'dimensions')

mastertableData(i,2) = position_x + str2double(get(handles.electrodedimensionEdittext,'String'))/2 ;

mastertableData(i,3) = position_y + str2double(get(handles.electrodedimensionEdittext,'String'))/2 ;

end

set(handles.masterTable,'Data',mastertableData);

end

