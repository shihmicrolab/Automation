function [  ] = space_real_time_actuation( handles,hObject )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

% Chekcing if Real time is ON

if get(handles.realtimeRadiobutton,'Value') == 1
    
    % Turning them on
    
    for i = 1:1:handles.grid_row
        for j = 1:1:handles.grid_collumn
            
            
          
            if get(handles.Electrode_pad(i,j),'Userdata') == 1
                
                
                
                % Getting the number of the electrode activated
                
                electrode_number = str2double(get(handles.Electrode_pad(i,j),'String'));
                
                 actuate_electrode_multiple_on( i,j, electrode_number,handles,hObject );
                
                
                
            end
        end
        
    end
    
    %%% Pause for the number of TIME ON %%% 
    
    pause(handles.time_electrode);
    
    %%% Pause for the number of TIME ON %%% 
    
    % Turning them off
    
    for i = 1:1:handles.grid_row
        for j = 1:1:handles.grid_collumn
            
            if get(handles.Electrode_pad(i,j),'Userdata') == 1
                
                % Getting the number of the electrode activated
                
                electrode_number = str2double(get(handles.Electrode_pad(i,j),'String'));
                
                actuate_electrode_multiple_off( i,j, electrode_number,handles );
                
                %%% sETTING THE userdata back to 0
                 set(handles.Electrode_pad(i,j),'Userdata',0);
                
                
                
            end
        end
        
    end
    
    
    
end

end

